import { MarketingWorkspace } from "@/components/marketing-workspace";

export default function Page() { return <MarketingWorkspace />; }
