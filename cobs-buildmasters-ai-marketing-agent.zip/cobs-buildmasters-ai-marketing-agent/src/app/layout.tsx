import type { Metadata } from "next";
import "./styles.css";

export const metadata: Metadata = {
  title: "COBS Buildmasters | Marketing Agent",
  description: "Private marketing operations workspace for COBS Buildmasters Ltd."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
