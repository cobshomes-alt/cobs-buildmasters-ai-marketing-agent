export const postStatuses = ["Draft", "Pending Approval", "Approved", "Scheduled", "Publishing", "Published", "Failed", "Rejected", "Cancelled"] as const;
export type PostStatus = (typeof postStatuses)[number];
export type Platform = "facebook" | "instagram" | "manual";

export interface MarketingPost {
  id: string; caption: string; platform: Platform; status: PostStatus;
  version: number; scheduledFor: string | null; approvedVersion: number | null;
}

export const mayQueue = (post: MarketingPost) => post.status === "Approved" && post.approvedVersion === post.version;
