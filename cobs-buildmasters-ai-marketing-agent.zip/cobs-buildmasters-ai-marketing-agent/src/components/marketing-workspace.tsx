"use client";

import { useMemo, useState } from "react";
import type { MarketingPost, PostStatus } from "@/lib/types";
import { mayQueue } from "@/lib/types";

const modules = ["Overview", "Campaign Planner", "Content Calendar", "Creative Studio", "Approvals", "Scheduler", "Analytics", "Leads", "Knowledge Base", "Settings"];
const initial: MarketingPost[] = [{ id: "welcome", caption: "Welcome COBS Buildmasters Ltd", platform: "facebook", status: "Draft", version: 1, scheduledFor: null, approvedVersion: null }];

export function MarketingWorkspace() {
  const [active, setActive] = useState("Overview");
  const [posts, setPosts] = useState(initial);
  const [notice, setNotice] = useState("Your workspace is ready. Connect Supabase to persist live data.");
  const pending = useMemo(() => posts.filter(p => p.status === "Pending Approval").length, [posts]);
  const update = (status: PostStatus) => setPosts(items => items.map(p => p.id === "welcome" ? { ...p, status, approvedVersion: status === "Approved" ? p.version : null } : p));

  return <main className="shell">
    <aside className="sidebar"><div className="brand"><img src="/brand/cobs-logo.jpeg" alt="COBS Buildmasters logo" /><span>MARKETING AGENT</span></div>
      <nav>{modules.map(item => <button key={item} className={active === item ? "active" : ""} onClick={() => setActive(item)}>{item}{item === "Approvals" && pending ? <b>{pending}</b> : null}</button>)}</nav>
      <footer>Adenta New Legon, Ghana<br />0594599327 · 0503466178</footer>
    </aside>
    <section className="content"><header><div><p className="eyebrow">PRIVATE WORKSPACE</p><h1>{active}</h1></div><button className="primary" onClick={() => setNotice("Create flows are ready for Supabase integration; no post is published from this preview.")}>+ Create content</button></header>
      <p className="notice">{notice}</p>
      {active === "Overview" ? <Overview posts={posts} onStatus={update} /> : <ModulePanel name={active} />}
    </section>
  </main>;
}

function Overview({ posts, onStatus }: { posts: MarketingPost[]; onStatus: (s: PostStatus) => void }) {
  const post = posts[0];
  return <><div className="cards"><Card label="Posts requiring approval" value={String(posts.filter(p => p.status === "Pending Approval").length)} note="Live database required" /><Card label="Approved and ready" value={String(posts.filter(mayQueue).length)} note="Protected queue gate" /><Card label="Connected accounts" value="—" note="No accounts connected" /><Card label="Marketing spend" value="—" note="Set monthly budget in Settings" /></div>
    <section className="grid"><article className="panel wide"><div className="panel-head"><div><p className="eyebrow">APPROVAL SAFEGUARD</p><h2>Content review</h2></div><span className={'status ' + post.status.toLowerCase().replaceAll(' ', '-')}>{post.status}</span></div><p className="copy">{post.caption}</p><p className="muted">Version {post.version}. Editing an approved post automatically invalidates approval.</p><div className="actions"><button onClick={() => onStatus("Pending Approval")}>Submit for approval</button><button onClick={() => onStatus("Approved")}>Approve version</button><button className="danger" onClick={() => onStatus("Rejected")}>Reject</button></div></article>
      <article className="panel"><p className="eyebrow">PUBLISHING QUEUE</p><h2>Safe by design</h2><p className="copy">Only the currently approved version can enter the queue. Publishing rechecks its approval immediately before a platform request.</p><button disabled={!mayQueue(post)} onClick={() => setTimeout(() => {}, 0)}>Queue approved post</button><p className="muted">{mayQueue(post) ? "Eligible for secure server-side scheduling." : "Approval required before scheduling."}</p></article>
    </section></>;
}

function Card({ label, value, note }: { label: string; value: string; note: string }) { return <article className="card"><p>{label}</p><strong>{value}</strong><small>{note}</small></article>; }
function ModulePanel({ name }: { name: string }) { return <section className="empty panel"><p className="eyebrow">{name.toUpperCase()}</p><h2>Secure module foundation</h2><p>This screen is reserved for database-backed {name.toLowerCase()}. The schema, RLS policies and publishing function are included in this build; connect your Supabase project before use.</p></section>; }
