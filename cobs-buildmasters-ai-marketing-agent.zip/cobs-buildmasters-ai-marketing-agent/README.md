# COBS Buildmasters AI Marketing Agent

Private, approval-first marketing operations foundation for COBS Buildmasters Ltd, Adenta New Legon, Ghana. It preserves the supplied navy, grey and gold identity and includes the supplied logo at `public/brand/cobs-logo.jpeg`.

## Current scope

This build delivers a responsive Next.js shell and the secure data foundation for the initial implementation phase. It deliberately does **not** claim that Meta publishing, OpenAI generation, analytics, scheduled jobs, or authentication are live: those require the owner's Supabase, OpenAI, Meta, Vercel and GitHub credentials/configuration.

The interface contains no fake marketing metrics. Its safe publishing control is disabled until a post has a matching approved version.

## Run locally

1. Install Node 20+ and pnpm.
2. Copy `.env.example` to `.env.local`; fill values only in the deployment environment or local secret file.
3. Create a Supabase project and apply `supabase/migrations/202610140001_initial_schema.sql` through the Supabase CLI or SQL editor.
4. Run `pnpm install` and `pnpm dev`.
5. Deploy the Edge Function using `supabase functions deploy publish-approved-post` only after configuring its server-side secrets.

## Security model

- The browser receives only public Supabase configuration; service role, OpenAI and Meta secrets are never browser variables.
- Row-level security scopes records to an organization; only an owner can manage accounts, queue jobs or review audit history.
- `enforce_post_version` clears the approved version after a content change and moves approved/scheduled content back to Draft.
- `approve_post` records the owner, version and timestamp.
- The Edge Function rechecks the current approved version while locking a job; a stale or altered job is cancelled rather than published.
- The publisher intentionally returns a configuration failure until official Meta OAuth, permissions, media validation and server-side token encryption are implemented.

## Requirement traceability

| Requirement | Implementation | Status / verification |
|---|---|---|
| Dashboard and mobile UI | `src/components/marketing-workspace.tsx`, `src/app/styles.css` | Implemented as UI foundation; visual runtime test pending dependency installation |
| Brand identity and supplied logo | `public/brand/cobs-logo.jpeg`, `styles.css` | Implemented |
| Core entities: content, media, campaigns, leads, knowledge | migration tables `posts`, `media_assets`, `campaigns`, `leads`, `brand_records` | Implemented in schema; migration not applied in this environment |
| Explicit workflow statuses | `post_status` enum | Implemented in schema |
| Approval version lock | `posts`, `approvals`, `enforce_post_version`, `approve_post` | Implemented in schema; requires Supabase integration test |
| Publishing recheck and idempotency | `publish_jobs`, Edge Function | Implemented as guarded stub; Meta call intentionally not configured |
| Social tokens and owner controls | `social_accounts`, RLS | Schema only; encryption/OAuth callback still required |
| Analytics | `analytics_snapshots` | Schema only; real Meta insight collector required |
| Budget controls / AI cost fields | `campaigns.budget_cap`, `posts.generation_cost` | Schema only; settings UI and cost collector required |
| Audit records / export | `audit_logs` | Schema only; trigger/export endpoint required |

## Acceptance-test plan before launch

1. Sign in as owner and marketer; prove that RLS prevents cross-organization access and marketer approval/account changes.
2. Create a post and `post_versions` row, approve it, then edit caption; assert status becomes Draft and `approved_version` is null.
3. Attempt to enqueue an unapproved or stale version; expect rejection.
4. Exercise a Meta sandbox publish, simulate timeout and retry; assert one external post per idempotency key and accurate Failure state/log.
5. Compare analytics records to a connected Meta account and leave unavailable values blank—not zero.
6. Export posts and audit logs, validate authorization and mobile/desktop UI.

## Deployment sequence

1. Create a private GitHub repository and push this project.
2. Create Supabase project, apply migration, configure Storage bucket policies and seed the one owner profile securely.
3. Complete OAuth redirect/callback and encrypt refresh tokens using a server-only key-management design.
4. Implement OpenAI generation through a Vercel server route with usage/cost logging and rate limiting.
5. Implement official Meta publishing/insights only after app review and required permissions are granted.
6. Deploy to Vercel with server-side environment variables; schedule the protected function using an authenticated cron caller.
