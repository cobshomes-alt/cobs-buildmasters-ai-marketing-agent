// Deploy as a Supabase Edge Function. Invoke only with a service role from a protected scheduler.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (request) => {
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const { jobId } = await request.json();
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: job, error } = await db.from("publish_jobs").select("*, posts(*)").eq("id", jobId).single();
  if (error || !job) return Response.json({ error: "Job not found" }, { status: 404 });
  const post = job.posts;
  // Recheck the exact approved version inside the server-only publishing boundary.
  if (job.state !== "queued" || post.status !== "Approved" || post.current_version !== job.approved_version || post.approved_version !== job.approved_version) {
    await db.from("publish_jobs").update({ state: "cancelled", error_message: "Post is no longer approved at this version." }).eq("id", jobId);
    return Response.json({ error: "Approval check failed" }, { status: 409 });
  }
  const { error: lockError } = await db.from("publish_jobs").update({ state: "locked", locked_at: new Date().toISOString(), attempts: job.attempts + 1 }).eq("id", jobId).eq("state", "queued");
  if (lockError) return Response.json({ error: "Job already locked" }, { status: 409 });
  // TODO: Fetch/decrypt token server-side and call the official Meta API. Never emit tokens to this response or a client.
  await db.from("publish_jobs").update({ state: "failed", error_message: "Meta publisher is not configured." }).eq("id", jobId);
  await db.from("posts").update({ status: "Failed" }).eq("id", post.id);
  return Response.json({ ok: false, state: "failed", reason: "Meta publisher is not configured" }, { status: 501 });
});
